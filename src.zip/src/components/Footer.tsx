import React from 'react';
import Link from 'next/link';
import { Sparkles, ArrowUpRight } from 'lucide-react';

const NAV_COLS = [
  {
    heading: 'Creator & Social',
    links: [
      { href: '/tools/youtube-money-calculator',        label: 'YouTube Money & RPM Calculator',    color: 'hover:text-rose-400' },
      { href: '/tools/youtube-shorts-earnings-estimator', label: 'YouTube Shorts Earnings Estimator', color: 'hover:text-rose-400' },
      { href: '/tools/tiktok-brand-deal-rate-calculator', label: 'TikTok Brand Deal Rate Calculator', color: 'hover:text-cyan-400' },
      { href: '/tools/instagram-engagement-rate-tool',  label: 'Instagram Engagement Rate Tool',     color: 'hover:text-pink-400' },
      { href: '/tools/patreon-earnings-estimator',      label: 'Patreon Earnings Estimator',        color: 'hover:text-rose-400' },
    ],
  },
  {
    heading: 'Business & Finance',
    links: [
      { href: '/tools/freelance-rate-calculator',      label: 'Freelance Rate & Quote Generator',  color: 'hover:text-emerald-400' },
      { href: '/tools/break-even-roas-calculator',     label: 'Break-Even ROAS & Profit Calc',     color: 'hover:text-blue-400' },
      { href: '/tools/amazon-fba-net-profit-calculator', label: 'Amazon FBA Net Profit Calculator', color: 'hover:text-amber-400' },
      { href: '/tools/salary-to-hourly-take-home',     label: 'Salary to Hourly Take-Home',        color: 'hover:text-emerald-400' },
    ],
  },
  {
    heading: 'Developer Tools',
    links: [
      { href: '/tools/regex-generator',        label: 'Plain English → Regex Generator', color: 'hover:text-amber-400' },
      { href: '/tools/schema-markup-generator', label: 'JSON-LD Schema Generator',        color: 'hover:text-violet-400' },
    ],
  },
  {
    heading: 'Health & Lifestyle',
    links: [
      { href: '/tools/macro-tdee-calculator', label: 'AI Macro & TDEE Calorie Planner', color: 'hover:text-emerald-400' },
    ],
  },
  {
    heading: 'Trust & Legal',
    links: [
      { href: '/privacy-policy', label: 'Privacy Policy',       color: 'hover:text-slate-200' },
      { href: '/terms-of-use',   label: 'Terms of Use',         color: 'hover:text-slate-200' },
      { href: '/disclaimer',     label: 'Earnings Disclaimer',  color: 'hover:text-slate-200' },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="relative mt-8 border-t border-white/[0.06]">
      {/* Top gradient line */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-violet-500/40 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-8 lg:gap-10">

          {/* Brand */}
          <div className="col-span-2 xl:col-span-1 space-y-4">
            <Link href="/" className="inline-flex items-center gap-2.5 group">
              <div className="relative w-8 h-8 flex-shrink-0">
                <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-violet-600 to-cyan-500 opacity-70 blur-[2px]" />
                <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
              </div>
              <span className="text-base font-bold text-white tracking-tight group-hover:text-violet-300 transition-colors">
                Tool<span className="text-violet-400">Calculators</span>
              </span>
            </Link>

            <p className="text-xs leading-relaxed text-slate-500">
              Free, practical calculators for creators, businesses, developers, and everyday planning.
            </p>

            <div className="text-[11px] text-slate-600">
              © {new Date().getFullYear()} ToolCalculators.
              <br />All rights reserved.
            </div>
          </div>

          {/* Nav columns */}
          {NAV_COLS.map((col) => (
            <div key={col.heading}>
              <h4 className="text-[11px] font-bold uppercase tracking-widest text-slate-400 mb-4">
                {col.heading}
              </h4>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className={`text-sm text-slate-500 ${link.color} transition-colors duration-200 inline-flex items-center gap-1 group/link`}
                    >
                      {link.label}
                      <ArrowUpRight className="w-3 h-3 opacity-0 group-hover/link:opacity-60 -translate-x-1 group-hover/link:translate-x-0 transition-all duration-200" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="mt-12 pt-8 border-t border-white/[0.05]">
          <p className="text-[11px] text-slate-600 leading-relaxed max-w-3xl">
            <span className="font-semibold text-slate-500">Disclaimer:</span>{' '}
            Calculator results are estimates for general information only — not financial, tax, legal, or medical advice.
            Actual outcomes depend on individual circumstances and may differ from estimates.
          </p>
        </div>
      </div>

      {/* Bottom glow */}
      <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-violet-900/5 to-transparent pointer-events-none" />
    </footer>
  );
}
