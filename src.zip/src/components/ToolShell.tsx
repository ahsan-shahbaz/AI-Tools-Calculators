import React, { ReactNode } from 'react';
import Link from 'next/link';
import { ChevronRight, ArrowLeft } from 'lucide-react';

interface Crumb {
  label: string;
  href?: string;
}

interface ToolShellProps {
  /** Icon emoji or element shown in the hero */
  icon: string;
  /** Badge text above the title, e.g. "YouTube · Social Media" */
  badge: string;
  /** Page <h1> */
  title: ReactNode;
  /** Sub-heading paragraph */
  subtitle: string;
  /** Optional accent color key for the glow ring – defaults to violet */
  accentColor?: 'violet' | 'cyan' | 'rose' | 'emerald' | 'amber';
  /** Breadcrumb items */
  breadcrumbs?: Crumb[];
  children: ReactNode;
}

const ACCENT_MAP: Record<string, { glow: string; border: string; badge: string; badgeText: string }> = {
  violet:  { glow: 'rgba(139,92,246,0.25)',  border: 'rgba(139,92,246,0.35)',  badge: 'bg-violet-500/10 border-violet-500/30 text-violet-300',  badgeText: '' },
  cyan:    { glow: 'rgba(6,182,212,0.2)',     border: 'rgba(6,182,212,0.35)',   badge: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300',          badgeText: '' },
  rose:    { glow: 'rgba(244,63,94,0.2)',     border: 'rgba(244,63,94,0.35)',   badge: 'bg-rose-500/10 border-rose-500/30 text-rose-300',          badgeText: '' },
  emerald: { glow: 'rgba(16,185,129,0.2)',    border: 'rgba(16,185,129,0.35)', badge: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300',  badgeText: '' },
  amber:   { glow: 'rgba(245,158,11,0.2)',    border: 'rgba(245,158,11,0.35)', badge: 'bg-amber-500/10 border-amber-500/30 text-amber-300',        badgeText: '' },
};

export default function ToolShell({
  icon,
  badge,
  title,
  subtitle,
  accentColor = 'violet',
  breadcrumbs = [],
  children,
}: ToolShellProps) {
  const accent = ACCENT_MAP[accentColor];

  return (
    <div className="relative z-10 pt-2 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Breadcrumb */}
        <nav aria-label="breadcrumb" className="flex items-center gap-1.5 text-xs mb-8 flex-wrap">
          <Link href="/" className="text-[--text-3] hover:text-[--text-2] transition-colors flex items-center gap-1">
            <ArrowLeft className="w-3 h-3" />
            Home
          </Link>
          {breadcrumbs.map((crumb, i) => (
            <React.Fragment key={i}>
              <ChevronRight className="w-3 h-3 text-[--text-3]" />
              {crumb.href ? (
                <Link href={crumb.href} className="text-[--text-3] hover:text-[--text-2] transition-colors">
                  {crumb.label}
                </Link>
              ) : (
                <span className="text-[--text-2] font-medium">{crumb.label}</span>
              )}
            </React.Fragment>
          ))}
        </nav>

        {/* Hero header */}
        <div className="relative text-center max-w-3xl mx-auto mb-12">
          {/* Ambient glow */}
          <div
            className="absolute inset-0 -top-8 rounded-full pointer-events-none blur-3xl"
            style={{ background: accent.glow }}
          />

          {/* Icon */}
          <div
            className="relative inline-flex items-center justify-center w-16 h-16 rounded-2xl text-3xl mb-5 mx-auto"
            style={{
              background: 'var(--bg-card)',
              border: `1px solid ${accent.border}`,
              boxShadow: `0 0 30px ${accent.glow}`,
            }}
          >
            {icon}
          </div>

          {/* Badge */}
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-semibold tracking-wider uppercase mb-4 ${accent.badge}`}>
            {badge}
          </div>

          {/* Title */}
          <h1 className="text-3xl sm:text-5xl font-black text-[--text-1] leading-tight tracking-tight mb-4">
            {title}
          </h1>

          <p className="text-sm sm:text-base text-[--text-2] leading-relaxed max-w-2xl mx-auto">
            {subtitle}
          </p>
        </div>

        {/* Tool content */}
        {children}

      </div>
    </div>
  );
}
