'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Theme = 'dark' | 'light' | 'midnight' | 'aurora';

interface ThemeContextType {
  theme: Theme;
  setTheme: (t: Theme) => void;
}

export const ThemeContext = createContext<ThemeContextType>({
  theme: 'dark',
  setTheme: () => {},
});

export function useTheme() {
  return useContext(ThemeContext);
}

export const THEMES: { id: Theme; label: string; icon: string; description: string }[] = [
  { id: 'dark',     label: 'Dark',     icon: '🌑', description: 'Classic dark' },
  { id: 'midnight', label: 'Midnight', icon: '🌌', description: 'Deep violet' },
  { id: 'aurora',   label: 'Aurora',   icon: '🌊', description: 'Cyan & teal' },
  { id: 'light',    label: 'Light',    icon: '☀️', description: 'Clean light' },
];

export const THEME_VARS: Record<Theme, Record<string, string>> = {
  dark: {
    '--bg-base':        '#060611',
    '--bg-surface':     '#0c0c1d',
    '--bg-card':        'rgba(255,255,255,0.03)',
    '--bg-card-hover':  'rgba(255,255,255,0.06)',
    '--border':         'rgba(255,255,255,0.08)',
    '--border-accent':  'rgba(139,92,246,0.35)',
    '--text-1':         '#f1f5f9',
    '--text-2':         '#94a3b8',
    '--text-3':         '#475569',
    '--accent-1':       '#8b5cf6',
    '--accent-2':       '#7c3aed',
    '--accent-glow':    'rgba(139,92,246,0.3)',
    '--orb-1':          'rgba(139,92,246,0.12)',
    '--orb-2':          'rgba(6,182,212,0.08)',
    '--orb-3':          'rgba(244,63,94,0.06)',
    '--grid-color':     'rgba(139,92,246,0.04)',
    '--btn-text':       '#ffffff',
    '--input-bg':       'rgba(255,255,255,0.05)',
    '--scrollbar':      'rgba(139,92,246,0.4)',
  },
  midnight: {
    '--bg-base':        '#02010f',
    '--bg-surface':     '#07051a',
    '--bg-card':        'rgba(255,255,255,0.025)',
    '--bg-card-hover':  'rgba(255,255,255,0.05)',
    '--border':         'rgba(255,255,255,0.06)',
    '--border-accent':  'rgba(99,102,241,0.45)',
    '--text-1':         '#e2e8f0',
    '--text-2':         '#8892a4',
    '--text-3':         '#3d4558',
    '--accent-1':       '#6366f1',
    '--accent-2':       '#4f46e5',
    '--accent-glow':    'rgba(99,102,241,0.35)',
    '--orb-1':          'rgba(99,102,241,0.15)',
    '--orb-2':          'rgba(168,85,247,0.1)',
    '--orb-3':          'rgba(59,130,246,0.06)',
    '--grid-color':     'rgba(99,102,241,0.03)',
    '--btn-text':       '#ffffff',
    '--input-bg':       'rgba(255,255,255,0.04)',
    '--scrollbar':      'rgba(99,102,241,0.5)',
  },
  aurora: {
    '--bg-base':        '#020d14',
    '--bg-surface':     '#061622',
    '--bg-card':        'rgba(255,255,255,0.03)',
    '--bg-card-hover':  'rgba(255,255,255,0.06)',
    '--border':         'rgba(255,255,255,0.07)',
    '--border-accent':  'rgba(6,182,212,0.4)',
    '--text-1':         '#ecfeff',
    '--text-2':         '#67e8f9',
    '--text-3':         '#0e7490',
    '--accent-1':       '#06b6d4',
    '--accent-2':       '#0891b2',
    '--accent-glow':    'rgba(6,182,212,0.3)',
    '--orb-1':          'rgba(6,182,212,0.12)',
    '--orb-2':          'rgba(20,184,166,0.08)',
    '--orb-3':          'rgba(99,102,241,0.06)',
    '--grid-color':     'rgba(6,182,212,0.04)',
    '--btn-text':       '#ffffff',
    '--input-bg':       'rgba(255,255,255,0.04)',
    '--scrollbar':      'rgba(6,182,212,0.4)',
  },
  light: {
    '--bg-base':        '#f8fafc',
    '--bg-surface':     '#f1f5f9',
    '--bg-card':        'rgba(255,255,255,0.9)',
    '--bg-card-hover':  'rgba(255,255,255,1)',
    '--border':         'rgba(15,23,42,0.1)',
    '--border-accent':  'rgba(139,92,246,0.4)',
    '--text-1':         '#0f172a',
    '--text-2':         '#475569',
    '--text-3':         '#94a3b8',
    '--accent-1':       '#7c3aed',
    '--accent-2':       '#6d28d9',
    '--accent-glow':    'rgba(124,58,237,0.2)',
    '--orb-1':          'rgba(139,92,246,0.08)',
    '--orb-2':          'rgba(6,182,212,0.06)',
    '--orb-3':          'rgba(244,63,94,0.04)',
    '--grid-color':     'rgba(15,23,42,0.04)',
    '--btn-text':       '#ffffff',
    '--input-bg':       'rgba(15,23,42,0.04)',
    '--scrollbar':      'rgba(139,92,246,0.3)',
  },
};

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>('dark');

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('tc-theme') as Theme | null;
      if (saved && THEME_VARS[saved]) setThemeState(saved);
    } catch {}
  }, []);

  // Apply CSS vars on theme change
  useEffect(() => {
    const vars = THEME_VARS[theme];
    const root = document.documentElement;
    Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v));
    root.setAttribute('data-theme', theme);
    try { localStorage.setItem('tc-theme', theme); } catch {}
  }, [theme]);

  const setTheme = (t: Theme) => setThemeState(t);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
