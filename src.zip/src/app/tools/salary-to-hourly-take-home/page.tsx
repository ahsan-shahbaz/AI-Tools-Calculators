'use client';

import React, { useMemo, useState } from 'react';
import Link from 'next/link';
import {
  ChevronRight,
  Copy,
  Check,
  Briefcase,
  Wallet,
  Calculator,
  Banknote
} from 'lucide-react';
import AdPlaceholder from '@/components/AdPlaceholder';
import { calculateSalaryTakeHome } from '@/lib/salary-take-home-calculator';

export default function SalaryToHourlyTakeHome() {
  const [annualSalary, setAnnualSalary] = useState<number>(90000);
  const [hoursPerWeek, setHoursPerWeek] = useState<number>(40);
  const [weeksPerYear, setWeeksPerYear] = useState<number>(50);
  const [taxRate, setTaxRate] = useState<number>(22);
  const [healthInsurance, setHealthInsurance] = useState<number>(4200);
  const [retirementContribution, setRetirementContribution] = useState<number>(6000);
  const [bonus, setBonus] = useState<number>(5000);
  const [copied, setCopied] = useState(false);

  const calculation = useMemo(() => calculateSalaryTakeHome({
    annualSalary,
    hoursPerWeek,
    weeksPerYear,
    taxRate,
    healthInsurance,
    retirementContribution,
    bonus,
  }), [annualSalary, hoursPerWeek, weeksPerYear, taxRate, healthInsurance, retirementContribution, bonus]);

  const handleCopy = () => {
    const text = `Take-Home Estimate\nAnnual gross: $${calculation.grossAnnualIncome}\nAnnual after-tax: $${calculation.netAnnualIncome}\nMonthly take-home: $${calculation.monthlyTakeHome}\nHourly take-home: $${calculation.hourlyTakeHome}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link href="/" className="hover:text-red-600 transition-colors">Home</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <Link href="/#categories" className="hover:text-red-600 transition-colors">Finance & Business</Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-800 font-medium">Salary to Hourly Take-Home</span>
        </nav>

        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Banknote className="w-4 h-4 text-emerald-600" />
            Salary Conversion
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-slate-900 leading-tight">
            Salary to <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600">Hourly Take-Home</span>
          </h1>
          <p className="mt-3 text-sm sm:text-base text-slate-600">
            Convert salary into realistic take-home hourly pay after tax, insurance, and retirement deductions.
          </p>
        </div>

        <AdPlaceholder slot="leaderboard" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mt-8">
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3 mb-5">
                <Briefcase className="w-5 h-5 text-emerald-600" />
                Salary Details
              </h2>

              <div className="space-y-5">
                <div>
                  <label htmlFor="salary-annual" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Annual salary ($)</label>
                  <input id="salary-annual" type="number" min="0" step="1000" value={annualSalary} onChange={(e) => setAnnualSalary(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
                <div>
                  <label htmlFor="salary-hours-per-week" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Hours per week</label>
                  <input id="salary-hours-per-week" type="number" min="0" step="1" value={hoursPerWeek} onChange={(e) => setHoursPerWeek(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
                <div>
                  <label htmlFor="salary-weeks-per-year" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Weeks per year</label>
                  <input id="salary-weeks-per-year" type="number" min="0" step="1" value={weeksPerYear} onChange={(e) => setWeeksPerYear(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
                <div>
                  <label htmlFor="salary-tax-rate" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Estimated tax rate (%)</label>
                  <input id="salary-tax-rate" type="number" min="0" max="100" step="1" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
                <div>
                  <label htmlFor="salary-health-insurance" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Health insurance ($ / year)</label>
                  <input id="salary-health-insurance" type="number" min="0" step="100" value={healthInsurance} onChange={(e) => setHealthInsurance(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
                <div>
                  <label htmlFor="salary-retirement" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Retirement contribution ($ / year)</label>
                  <input id="salary-retirement" type="number" min="0" step="100" value={retirementContribution} onChange={(e) => setRetirementContribution(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
                <div>
                  <label htmlFor="salary-bonus" className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">Bonus ($ / year)</label>
                  <input id="salary-bonus" type="number" min="0" step="100" value={bonus} onChange={(e) => setBonus(Number(e.target.value) || 0)} className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-800" />
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6">
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 text-white shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                  <Calculator className="w-4 h-4" />
                  Take-Home Estimate
                </span>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied!' : 'Copy Result'}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-xl bg-slate-800/80 p-4 border border-slate-700">
                  <p className="text-[10px] uppercase tracking-wider text-slate-400">Gross Income</p>
                  <p className="text-2xl font-black text-emerald-400 mt-2">${calculation.grossAnnualIncome.toLocaleString()}</p>
                </div>
                <div className="rounded-xl bg-slate-800/80 p-4 border border-slate-700">
                  <p className="text-[10px] uppercase tracking-wider text-slate-400">Annual Taxes</p>
                  <p className="text-2xl font-black text-cyan-300 mt-2">${calculation.annualTaxes.toLocaleString()}</p>
                </div>
                <div className="rounded-xl bg-slate-800/80 p-4 border border-slate-700">
                  <p className="text-[10px] uppercase tracking-wider text-slate-400">Net Annual Income</p>
                  <p className="text-2xl font-black text-amber-300 mt-2">${calculation.netAnnualIncome.toLocaleString()}</p>
                </div>
                <div className="rounded-xl bg-slate-800/80 p-4 border border-slate-700">
                  <p className="text-[10px] uppercase tracking-wider text-slate-400">Hourly Take-Home</p>
                  <p className="text-2xl font-black text-violet-300 mt-2">${calculation.hourlyTakeHome.toFixed(2)}</p>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="rounded-xl bg-slate-800 p-4 border border-slate-700">
                  <p className="text-xs text-slate-400">Monthly take-home</p>
                  <p className="mt-2 text-xl font-bold text-emerald-300">${calculation.monthlyTakeHome.toFixed(0)}</p>
                </div>
                <div className="rounded-xl bg-slate-800 p-4 border border-slate-700">
                  <p className="text-xs text-slate-400">Effective gross hourly</p>
                  <p className="mt-2 text-xl font-bold text-cyan-300">${calculation.effectiveHourlyGross.toFixed(2)}</p>
                </div>
                <div className="rounded-xl bg-slate-800 p-4 border border-slate-700">
                  <p className="text-xs text-slate-400">Tax rate</p>
                  <p className="mt-2 text-xl font-bold text-amber-300">{taxRate}%</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-4">
                <Wallet className="w-5 h-5 text-emerald-600" />
                Planning Insight
              </h3>
              <ul className="space-y-3 text-sm text-slate-600 leading-relaxed">
                <li>• Your effective take-home rate is often much lower than headline salary because taxes and benefits matter.</li>
                <li>• Comparing hourly pay with freelance or contract work requires the same time-based denominator.</li>
                <li>• Retirement contributions and healthcare costs can materially reduce disposable income despite a strong salary.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
