import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { ThemeProvider } from '@/components/ThemeProvider';
import { SITE_URL } from '@/lib/site';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: 'Free Online Calculators for Creators & Businesses | ToolCalculators',
    template: '%s | ToolCalculators — Free Online Tools',
  },
  description:
    'Free online calculators for creator earnings, freelance rates, ecommerce profit, YouTube RPM, TikTok brand deals, SEO, developer tools, and everyday planning. Instant results, no account required.',
  keywords: [
    'free online calculators',
    'youtube money calculator',
    'youtube rpm calculator',
    'youtube earnings estimator',
    'freelance rate calculator',
    'tiktok brand deal calculator',
    'instagram engagement rate',
    'amazon fba profit calculator',
    'break even roas calculator',
    'salary to hourly calculator',
    'patreon earnings estimator',
    'macro calorie calculator',
    'regex generator',
    'schema markup generator',
  ],
  authors: [{ name: 'ToolCalculators' }],
  alternates: { canonical: '/' },
  robots: { index: true, follow: true },
  openGraph: {
    title: 'Free Online Calculators for Creators & Businesses | ToolCalculators',
    description: 'Free, practical calculators for creators, businesses, developers, and everyday planning. Instant results, no account.',
    type: 'website',
    siteName: 'ToolCalculators',
    url: '/',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Free Online Calculators | ToolCalculators',
    description: 'Practical free calculators for creators, businesses, developers, and everyday planning.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* Inline script to apply saved theme BEFORE paint — prevents FOUC */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                var t = localStorage.getItem('tc-theme') || 'dark';
                var themes = {
                  dark:     { '--bg-base':'#060611','--text-1':'#f1f5f9','--accent-1':'#8b5cf6','--accent-2':'#7c3aed','--orb-1':'rgba(139,92,246,0.12)','--orb-2':'rgba(6,182,212,0.08)','--orb-3':'rgba(244,63,94,0.06)' },
                  midnight: { '--bg-base':'#02010f','--text-1':'#e2e8f0','--accent-1':'#6366f1','--accent-2':'#4f46e5','--orb-1':'rgba(99,102,241,0.15)','--orb-2':'rgba(168,85,247,0.1)','--orb-3':'rgba(59,130,246,0.06)' },
                  aurora:   { '--bg-base':'#020d14','--text-1':'#ecfeff','--accent-1':'#06b6d4','--accent-2':'#0891b2','--orb-1':'rgba(6,182,212,0.12)','--orb-2':'rgba(20,184,166,0.08)','--orb-3':'rgba(99,102,241,0.06)' },
                  light:    { '--bg-base':'#f8fafc','--text-1':'#0f172a','--accent-1':'#7c3aed','--accent-2':'#6d28d9','--orb-1':'rgba(139,92,246,0.08)','--orb-2':'rgba(6,182,212,0.06)','--orb-3':'rgba(244,63,94,0.04)' },
                };
                var vars = themes[t] || themes['dark'];
                var root = document.documentElement;
                Object.keys(vars).forEach(function(k){ root.style.setProperty(k, vars[k]); });
                root.setAttribute('data-theme', t);
                root.style.backgroundColor = vars['--bg-base'];
              } catch(e) {}
            `,
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'WebSite',
              name: 'ToolCalculators',
              alternateName: 'Tool Calculators',
              url: SITE_URL,
              description: 'Free online calculators for creators, businesses, developers, and everyday planning.',
              potentialAction: {
                '@type': 'SearchAction',
                target: `${SITE_URL}/?q={search_term_string}`,
                'query-input': 'required name=search_term_string',
              },
            }),
          }}
        />
      </head>
      <body className="flex flex-col min-h-screen antialiased">
        <ThemeProvider>
          <Header />
          <main className="flex-1 relative z-10">
            {children}
          </main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}
